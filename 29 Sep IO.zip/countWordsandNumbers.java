 //Ask user to enter file path. Count number of words in that file, count number of numbers in that file.


package com.yash.io;
import java.io.BufferedReader;

import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
public class countWordsandNumbers {
		
	@SuppressWarnings("null")
	public static void main(String[] args) throws IOException {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the File Path:");
		String Filename=scan.nextLine();
		scan.close();
		String s=null;
		int count1=0;
		int flag=0;
		int count=0;
		int j=0;
		try{
			FileReader filereader=new FileReader(Filename);
			BufferedReader bufferedReader=new BufferedReader(filereader);

			while((s=bufferedReader.readLine())!=null){
				while (j < s.length()) {
			    	if (s.charAt(j) == ' ' || s.charAt(j) == '\n' || s.charAt(j) == '\t')
			        {
			           flag = 0;
			        }else if (flag == 0) {
			           flag = 1;
			           count++;
			        }
			        j++;
			     }
				for(int i=0;i<s.length();i++)
			      {
			        if(Character.isDigit(s.charAt(i)))
			        count1++;
			      }
			      System.out.println("\n"+s);
			      System.out.println("The string is: \n" + s);
			      System.out.println("No of numbers in the above string are: \n" + count1);
			      System.out.println("Numbers of words in file are:"+count);
			}
			bufferedReader.close();
		}catch(IOException e) {
			e.printStackTrace();
		}	
		     }
	}	